(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.sunburst = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _shallowequal = require('shallowequal');

var _shallowequal2 = _interopRequireDefault(_shallowequal);

var _d3Color = require('d3-color');

var _d3Selection = require('d3-selection');

var _d3Scale = require('d3-scale');

var _d3Hierarchy = require('d3-hierarchy');

var _d3Shape = require('d3-shape');

var _d3Path = require('d3-path');

var _d3Interpolate = require('d3-interpolate');

var _d3Transition = require('d3-transition');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// We have to import this event though we dont use it


_d3Transition.transition;

/* REFS
 * zoomable /w/ labels -- https://bl.ocks.org/vasturiano/12da9071095fbd4df434e60d52d2d58d
 * text opacity -- https://gist.github.com/metmajer/5480307
*/

/**
* Creates a zoomable Sunburst
* @param {object} props
* @param {object} props.data - see the d3 {@link https://github.com/defunctzombie/d3-examples/blob/master/dendrogram/flare.json|flare.json}
    data for the shape that is required. 
* @param {string} props.width - width of svg
* @param {string} props.height - height of svg. 
*   If width and height are not the same there will be dead space.
* @param {number} props.count_member - what data element to use for slice size
* @param {number} [props.radianCutoff=.01] - smallest slice to show in radians
* @param {number} [props.transitionDuration=500] - ms for animation
* @param {number} [props.saturation=.5] - base color saturation of slices
* @param {number} [props.lightness=.5] - base color lightness of slices
* @param {number} [props.child_brightness=.5] - value to lighten children slices
* @param {number} [props.font_size=12] - for calculating if text fits
* @param {func} [props.colorFunc=(node, current_color) => current_color]
        - Custom color func for slices with heights > 0.
* @param {func} [props.labelFunc] - returns text to slice
* @param {func} [props.condensedLabelFunc] - backup function to try to fit less text
        for smaller slices.
* @param {func} [props.tooltipFunc=(data) => data.name]
* @param {number} [props.tooltipX=20] - x pointer offset to show tooltip 
* @param {number} [props.tooltipY=20] - y pionter offset to show tooltip
* @param {string} [props.domID] - will be random if undefined
* @param {func} [props.onMouseover]
* @param {func} [props.onMouseout]
* @param {func} [props.onClick]
* @param {string} [props.key_member] - data member to construct dom ids from

*/
//FIXME normalize function signatures
//FIXME normalize case

var Sunburst = function (_React$Component) {
    _inherits(Sunburst, _React$Component);

    function Sunburst(props) {
        _classCallCheck(this, Sunburst);

        var _this = _possibleConstructorReturn(this, (Sunburst.__proto__ || Object.getPrototypeOf(Sunburst)).call(this, props));

        _this._last_click = null;
        _this.radius = Math.min(_this.props.width, _this.props.height) / 2;
        _this.y = (0, _d3Scale.scaleSqrt)().range([0, _this.radius]);

        _this.x = (0, _d3Scale.scaleLinear)().range([0, 2 * Math.PI]);

        _this.arc = (0, _d3Shape.arc)().startAngle(function (d) {
            return Math.max(0, Math.min(2 * Math.PI, _this.x(d.x0)));
        }).endAngle(function (d) {
            return Math.max(0, Math.min(2 * Math.PI, _this.x(d.x1)));
        }).innerRadius(function (d) {
            return Math.max(0, _this.y(d.y0));
        }).outerRadius(function (d) {
            return Math.max(0, _this.y(d.y1));
        });

        _this.partition = (0, _d3Hierarchy.partition)();

        _this.hueDXScale = (0, _d3Scale.scaleLinear)().domain([0, 1]).range([0, 360]);

        _this.domId = _this.props.domId || 'sunburst-wrapper-' + Math.round(Math.random() * 1e12).toString();
        _this.svg = null;
        _this.tooltipDom = null;
        _this.lastSelect = null;
        return _this;
    }

    _createClass(Sunburst, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.props._debug && this.props._log("Sunburst: componentDidMount()");
            this._create();
        }
    }, {
        key: 'shouldComponentUpdate',
        value: function shouldComponentUpdate(nextProps) {
            this.props._debug && this.props._log("Sunburst: shouldComponentUpdate()", this.props);
            if (!(0, _shallowequal2.default)(this.props, nextProps)) {
                return false;
            }
            return true;
        }
    }, {
        key: '_destroy_svg',
        value: function _destroy_svg() {
            this.props._debug && this.props._log("Sunburst: _destroy_svg()");
            this.svg && this.svg.selectAll('*').remove();
            this.svg = null;
        }
    }, {
        key: 'componentDidUpdate',
        value: function componentDidUpdate() {
            //prevProps
            this.props._debug && this.props._log("Sunburst: componentDidUpdate()");
            this._destroy_svg();
            this._create();
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            this.props._debug && this.props._log("Sunburst: componentWillUnmount()");
            this._destroy_svg();
        }
        /**
         * Programatically select a slice.
         * @param id the slice key to select. This should be the key_member set in
         * props.
        */

    }, {
        key: 'select',
        value: function select(id) {
            this.props._debug && this.props._log("Sunburst: select(id)");
            var key = '#mainArc-' + id;
            var nodes = (0, _d3Selection.select)(key).nodes();
            if (!nodes.length) {
                this.props._warn('could not find node with id of ' + key);
                return;
            }
            var node = nodes[0].__data__;
            this._update(node);
        }
    }, {
        key: '_onClick',
        value: function _onClick(node) {
            this.props._debug && this.props._log("Sunburst: _onClick(node)");
            this._last_click = node;
        }

        /**
         * recomputes slice colors. If the color function changes this should be called
         * to update to the new color sheme.
        */

    }, {
        key: 'updateColor',
        value: function updateColor() {
            var _this2 = this;

            this.props._debug && this.props._log("Sunburst: updateColor()");
            this.svg.selectAll('path.sunburst-main-arc').style("fill", function (d) {
                return d.parent ? _this2._colorize(d) : "white";
            });
        }
    }, {
        key: '_create',
        value: function _create() {
            var _this3 = this;

            this.props._debug && this.props._log("Sunburst: _create()");
            if (!this.props.data) return;

            var root = (0, _d3Hierarchy.hierarchy)(this.props.data).sum(function (d) {
                if (d[this.props.count_member] === undefined) this.props._warn('props.count_member (' + this.props.count_member + ') is not defined on data');
                return !d.children || d.children.length === 0 ? d[this.props.count_member] : 0;
            }.bind(this));
            //.filter( (d) => d.depth < 4)

            var data = this.partition(root).descendants().filter(function (d) {
                return d.x1 - d.x0 > _this3.props.radianCutoff;
            }); // 0.005 radians = 0.29 degrees

            if (!this.svg) {
                var w = this.props.width;
                var h = this.props.height;
                var el = (0, _d3Selection.select)('#' + this.domId);

                this.svg = el.append('svg');
                this.svg.style('class', 'sunburst-svg').style('width', w + 'px').style('height', h + 'px').attr('viewBox', -w / 2 + ' ' + -h / 2 + ' ' + w + ' ' + h);
                //this.canvas = this.svg.append('g');
                //this.svg = d3Select("svg").append("g").attr("id", "bigG")

                var gSlices = this.svg.selectAll("g").data(data).enter().append("g");

                gSlices.exit().remove();

                var key = this.props.key_member;
                gSlices.append("path").attr('class', function (d) {
                    var cursor = !d.parent || !d.children ? ' cursor-pointer' : ' cursor-pointer';
                    var evenodd = d.depth % 2 ? 'even-row' : 'odd-row';
                    return 'sunburst-main-arc' + cursor + ' ' + evenodd;
                }).attr('id', function (d, i) {
                    return key ? 'mainArc-' + d.data[key] : 'mainArc-' + i;
                }).style("fill", function (d) {
                    return d.parent ? _this3._colorize(d) : "white";
                }).on('click', function (node) {
                    this._onClick(node);
                    this.props.onClick && this.props.onClick(node);
                    this._update(node);
                }.bind(this));

                if (this.props.labelFunc) {
                    gSlices.append('path').attr('class', 'sunburst-hidden-arc').attr('id', function (_, i) {
                        return 'hiddenArc' + i;
                    }).attr('d', this._middleArcLine.bind(this)).style('fill', 'none');

                    var text = gSlices.append('text').style('pointer-events', 'none').style('dominant-baseline', 'middle').style('text-anchor', 'middle');
                    //.attr('display', d => this._textFits(d) ? null : 'none')

                    text.append('textPath').attr('startOffset', '50%').attr('xlink:href', function (_, i) {
                        return '#hiddenArc' + i;
                    }).text(function (d) {
                        return _this3._getLabelText(d) || '';
                    });
                }
            }
            this.props.tooltip && this._setTooltips();
            this._update(root);
        }
    }, {
        key: '_update',
        value: function _update(d, i, a) {
            var _this4 = this;

            this.props._debug && this.props._log("Sunburst: _update(d, i, a)");

            if (this.lastSelect && a && this.lastSelect == a[i].id) return;

            this.lastSelect = a && a[i].id;

            this.svg.transition().selectAll('textPath').attr("opacity", 0);

            var transition = this.svg.transition().duration(this.props.transitionDuration) // duration of transition
            .tween("scale", function () {
                var xd = (0, _d3Interpolate.interpolate)(this.x.domain(), [d.x0, d.x1]),
                    yd = (0, _d3Interpolate.interpolate)(this.y.domain(), [d.y0, 1]),
                    yr = (0, _d3Interpolate.interpolate)(this.y.range(), [d.y0 ? 20 : 0, this.radius]);
                return function (t) {
                    this.x.domain(xd(t));this.y.domain(yd(t)).range(yr(t));
                }.bind(this);
            }.bind(this));

            transition.selectAll('path.sunburst-hidden-arc').attrTween('d', function (d) {
                return function () {
                    return _this4._middleArcLine(d);
                };
            });

            //.style("fill", (d) => d.parent ? this._colorize(d) : "white")
            transition.selectAll('path.sunburst-main-arc').attrTween('d', function (d) {
                return function () {
                    var arc = _this4.arc(d);
                    return arc;
                };
            }).on("end", function (e, i, a) {
                if (!_this4.arc.innerRadius()(e)) // if its not visible
                    return;
                // get a selection of the associated text element
                var arcText = (0, _d3Selection.select)(a[i].parentNode).select("text textPath");
                // fade in the text element and recalculate positions
                arcText.transition(_this4.props.transitionDuration / 2).attr("opacity", 1).text(function (d) {
                    var text = _this4._getLabelText(d);
                    return text;
                });
            });
        }
    }, {
        key: '_textFits',
        value: function _textFits(d, label) {
            this.props._debug && this.props._log("Sunburst: _textFits(d, label)");

            if (!label) return false;
            // changed to degress
            var angle = (this.arc.endAngle()(d) - this.arc.startAngle()(d)) * 57.296;
            var radius = this.arc.outerRadius()(d);
            var arclength = 2 * Math.PI * radius * (angle / 360);
            return label.length * this.props.font_size < arclength;
        }
    }, {
        key: '_getLabelText',
        value: function _getLabelText(d) {
            this.props._debug && this.props._log("Sunburst: _getLabelText(d)");
            var label;
            label = this.props.labelFunc && this.props.labelFunc(d);
            if (this._textFits(d, label)) return label;
            label = this.props.condensedLabelFunc && this.props.condensedLabelFunc(d);
            if (this._textFits(d, label)) return label;
            return null;
        }
    }, {
        key: '_middleArcLine',
        value: function _middleArcLine(d) {
            this.props._debug && this.props._log("Sunburst: _middleArcLine(d)");
            var halfPi = Math.PI / 2;
            var angles = [this.x(d.x0) - halfPi, this.x(d.x1) - halfPi];
            var r = Math.max(0, (this.y(d.y0) + this.y(d.y1)) / 2);

            var middleAngle = (angles[1] + angles[0]) / 2;
            var invertDirection = middleAngle > 0 && middleAngle < Math.PI; // On lower quadrants write text ccw
            if (invertDirection) {
                angles.reverse();
            }

            var path = (0, _d3Path.path)();
            path.arc(0, 0, r, angles[0], angles[1], invertDirection);
            return path.toString();
        }
    }, {
        key: '_inDomain',
        value: function _inDomain(d) {
            this.props._debug && this.props._log("Sunburst: _inDomain(d)");
            var d0 = this.x.domain()[0];
            var d1 = this.x.domain()[1];
            if (d.x0 < d0) return false;
            if (d.x1 > d1) return false;
            return true;
        }
    }, {
        key: '_setTooltips',
        value: function _setTooltips() {

            this.props._debug && this.props._.log("Sunburst: _setTooltips(d)");
            this.tooltipDom = (0, _d3Selection.select)('#' + this.domId).append('div').attr('class', 'sunburst-tooltip').style('position', 'absolute').style('z-index', '10').style('opacity', '0').style('text-align', 'center').style('border-radius', '8px')
            //.style('max-width', '20em')
            .style('pointer-events', 'none').style('background', 'lightsteelblue').style('padding', '3px');

            var dx = this.props.tooltipX;
            var dy = this.props.tooltipY;
            this.svg.selectAll('path.sunburst-main-arc').on("mouseover", function (d) {
                if (this.props.tooltip) {
                    this.tooltipDom.html(this.props.tooltipFunc(d.data)).style("left", _d3Selection.event.pageX + dx + "px").style("top", _d3Selection.event.pageY + dy + "px");
                    this.tooltipDom.transition().style("opacity", .9).duration(200);

                    this.props.onMouseover && this.props.onMouseover(d.data);
                }
            }.bind(this)).on("mouseout", function (d) {
                this.props.tooltip && this.tooltipDom.transition().style("opacity", 0).duration(500);

                this.props.onMouseout && this.props.onMouseout(d.data);
            }.bind(this));
        }
    }, {
        key: '_colorize',
        value: function _colorize(d) {
            this.props._debug && this.props._log("Sunburst: _colorize(d)");
            var hue = void 0;
            var current = d;
            if (current.depth === 0) {
                return '#33cccc';
            }
            var _props = this.props,
                lightness = _props.lightness,
                saturation = _props.saturation,
                child_brightness = _props.child_brightness;

            if (current.depth <= 1) {
                hue = this.hueDXScale(d.x0);
                current.fill = (0, _d3Color.hsl)(hue, saturation, lightness);
                return current.fill;
            }
            current.fill = current.parent.fill.brighter(child_brightness);
            var thishsl = (0, _d3Color.hsl)(current.fill);
            hue = this.hueDXScale(current.x0);
            var colorshift = thishsl.h + hue / 4;
            var c = (0, _d3Color.hsl)(colorshift, thishsl.s, thishsl.l);
            return this.props.colorFunc || this.props.colorFunc(d, c) || c;
        }

        // we have to render first then componentMounted will give us
        // access to the dom

    }, {
        key: 'render',
        value: function render() {
            this.props._debug && this.props._log("Sunburst: render()");
            return _react2.default.createElement('div', { className: 'sunburst-wrapper', id: this.domId });
        }
    }]);

    return Sunburst;
}(_react2.default.Component);

Sunburst.propTypes = {
    data: _propTypes2.default.object.isRequired,
    width: _propTypes2.default.string.isRequired,
    height: _propTypes2.default.string.isRequired,
    count_member: _propTypes2.default.string.isRequired,

    // requried /w/ default
    tooltip: _propTypes2.default.bool.isRequired, // FIXME get rid of this
    radianCutoff: _propTypes2.default.number.isRequired, // smallest slice to show in radians
    transitionDuration: _propTypes2.default.number.isRequired, // ms for animation
    saturation: _propTypes2.default.number.isRequired, // base saturation of arcs
    lightness: _propTypes2.default.number.isRequired, // base lightness of parent arcs
    child_brightness: _propTypes2.default.number.isRequired, // value to lighten children
    font_size: _propTypes2.default.number.isRequired, // for calculating if text fits

    colorFunc: _propTypes2.default.func, // custom colorizing for slice
    tooltipFunc: _propTypes2.default.func,
    tooltipX: _propTypes2.default.number.isRequired, // offset x to place tooltip
    tooltipY: _propTypes2.default.number.isRequired, // ofset y to place tooltip

    domId: _propTypes2.default.string, // will be random if undefined
    onMouseover: _propTypes2.default.func,
    onMouseout: _propTypes2.default.func,
    onClick: _propTypes2.default.func,
    labelFunc: _propTypes2.default.func, // returns text for slice
    condensedLabelFunc: _propTypes2.default.func, // backup function to try to fit text
    key_member: _propTypes2.default.string, // unique id
    _debug: _propTypes2.default.bool,
    _log: _propTypes2.default.func,
    _warn: _propTypes2.default.func
};
Sunburst.defaultProps = {
    tooltip: true,
    tooltipFunc: function tooltipFunc(data) {
        return data.name;
    },
    radianCutoff: .001,
    transitionDuration: 500,
    colorFunc: function colorFunc(node, current_color) {
        return current_color;
    },
    key_member: 'key',
    font_size: 12,
    tooltipX: 20,
    tooltipY: 20,
    saturation: .5,
    lightness: .5,
    child_brightness: .5,
    _debug: false,
    _log: console.log,
    _warn: console.warn
};
exports.default = Sunburst;

},{"d3-color":"d3-color","d3-hierarchy":"d3-hierarchy","d3-interpolate":"d3-interpolate","d3-path":"d3-path","d3-scale":"d3-scale","d3-selection":"d3-selection","d3-shape":"d3-shape","d3-transition":"d3-transition","prop-types":"prop-types","react":"react","shallowequal":"shallowequal"}]},{},[1])(1)
});
